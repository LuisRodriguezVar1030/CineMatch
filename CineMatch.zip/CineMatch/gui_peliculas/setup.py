# setup.py MEJORADO
from setuptools import setup, Extension
import pybind11
import os
import sys

# Detectar Windows y configurar accordingly
if sys.platform == "win32":
    compile_args = ["/std:c++17", "/O2"]
else:
    compile_args = ["-std=c++17", "-O3", "-fPIC"]

# Encontrar todos los archivos .cpp
cpp_files = []
for root, dirs, files in os.walk("src"):
    for file in files:
        if file.endswith(".cpp") and file != "main.cpp":
            cpp_files.append(os.path.join(root, file))

cpp_files.append("bindings.cpp")

ext_modules = [
    Extension(
        "recomendaciones",
        cpp_files,
        include_dirs=[
            "include",
            pybind11.get_include(),
        ],
        language='c++',
        extra_compile_args=compile_args,
    ),
]

setup(
    name="recomendaciones",
    ext_modules=ext_modules,
    zip_safe=False,
    python_requires='>=3.6',
)