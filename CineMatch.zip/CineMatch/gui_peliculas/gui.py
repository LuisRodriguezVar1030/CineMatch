# sistema_recomendaciones_gui_profesional.py
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import recomendaciones # type: ignore
import os

class SistemaRecomendacionesProfesional:
    def __init__(self, root):
        self.root = root
        self.root.title("🎬 CineMatch        Sistema de Recomendaciones")
        self.root.geometry("1100x750")
        self.root.configure(bg='#ffffff')
        
        # Configuración de estilo profesional
        self.setup_estilo_profesional()
        
        self.sistema = recomendaciones.SistemaRecomendador()
        self.cargar_datos_iniciales()
        self.crear_interfaz()
        self.actualizar_estado_sistema()
    
    def setup_estilo_profesional(self):
        """Configurar estilo visual profesional"""
        self.colors = {
            'primary': '#2563eb',      # Azul profesional
            'primary_dark': '#1d4ed8',
            'secondary': '#64748b',    # Gris azulado
            'accent': '#dc2626',       # Rojo profesional
            'success': '#059669',      # Verde esmeralda
            'warning': '#d97706',      # Ámbar
            'light': '#f8fafc',        # Fondo muy claro
            'card_bg': '#ffffff',      # Blanco puro
            'border': '#e2e8f0',       # Borde sutil
            'text_primary': '#1e293b', # Texto oscuro
            'text_secondary': '#475569' # Texto secundario
        }
        
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Configurar estilos profesionales
        self.style.configure('Professional.TFrame', background=self.colors['light'])
        self.style.configure('Card.TFrame', background=self.colors['card_bg'], relief='flat', borderwidth=1)
        
        # Botones modernos
        self.style.configure('Primary.TButton', 
                           background=self.colors['primary'],
                           foreground='white',
                           font=('Segoe UI', 10, 'bold'),
                           borderwidth=0,
                           focuscolor='none')
        self.style.map('Primary.TButton',
                      background=[('active', self.colors['primary_dark']),
                                ('pressed', self.colors['primary_dark'])])
    
    def cargar_datos_iniciales(self):
        """Cargar datos desde archivo CSV si existe"""
        try:
            # Verificar si el archivo existe
            archivo_csv = "peliculas.csv"
            if os.path.exists(archivo_csv):
                if self.sistema.cargarDesdeArchivo(archivo_csv):
                    print("✅ Datos cargados exitosamente desde peliculas.csv")
                else:
                    print("⚠️ El archivo existe pero no se pudo cargar - comenzando con sistema vacío")
            else:
                print("📝 Archivo peliculas.csv no encontrado - comenzando con sistema vacío")
                # Crear archivo vacío para evitar errores futuros
                with open(archivo_csv, 'w', encoding='utf-8') as f:
                    f.write("id,titulo,director,genero,puntuacion,ano,duracion\n")
        except Exception as e:
            print(f"❌ Error cargando datos: {e}")

    def crear_interfaz(self):
        """Interfaz principal limpia y profesional"""
        main_frame = ttk.Frame(self.root, style='Professional.TFrame', padding="15")
        main_frame.pack(fill='both', expand=True)
        
        self.crear_header(main_frame)
        self.crear_panel_estado(main_frame)
        self.crear_pestañas_principales(main_frame)
    
    def crear_header(self, parent):
        """Crear encabezado de la aplicación"""
        header_frame = ttk.Frame(parent, style='Professional.TFrame')
        header_frame.pack(fill='x', pady=(0, 15))
        
        # Logo y título
        ttk.Label(header_frame, text="🎬 CineMatch", 
                 font=('Segoe UI', 20, 'bold'),
                 background=self.colors['light'],
                 foreground=self.colors['primary']).pack(side='left')
        
        ttk.Label(header_frame, text="Sistema de Recomendaciones de Películas",
                 font=('Segoe UI', 11),
                 background=self.colors['light'],
                 foreground=self.colors['text_secondary']).pack(side='left', padx=(10, 0), pady=(5, 0))
    
    def crear_panel_estado(self, parent):
        """Crear panel de estado del sistema"""
        estado_frame = ttk.Frame(parent, style='Card.TFrame', padding="15")
        estado_frame.pack(fill='x', pady=(0, 15))
        
        ttk.Label(estado_frame, text="📊 Estado del Sistema", 
                 font=('Segoe UI', 12, 'bold'),
                 background=self.colors['card_bg']).pack(anchor='w', pady=(0, 10))
        
        # Métricas
        metrics_frame = ttk.Frame(estado_frame, style='Card.TFrame')
        metrics_frame.pack(fill='x')
        
        self.metric_vars = {
            'total': tk.StringVar(value="0"),
            'generos': tk.StringVar(value="0"),
            'puntuacion_promedio': tk.StringVar(value="0.0")
        }
        
        metrics = [
            ("Películas Totales", self.metric_vars['total'], self.colors['primary']),
            ("Géneros Únicos", self.metric_vars['generos'], self.colors['success']),
            ("Puntuación Promedio", self.metric_vars['puntuacion_promedio'], self.colors['warning'])
        ]
        
        for i, (label, var, color) in enumerate(metrics):
            metric_frame = ttk.Frame(metrics_frame, style='Card.TFrame')
            metric_frame.grid(row=0, column=i, padx=20, sticky='ew')
            metrics_frame.columnconfigure(i, weight=1)
            
            ttk.Label(metric_frame, text=label, 
                     background=self.colors['card_bg'],
                     font=('Segoe UI', 9)).pack()
            ttk.Label(metric_frame, textvariable=var,
                     background=self.colors['card_bg'],
                     foreground=color,
                     font=('Segoe UI', 16, 'bold')).pack()
    
    def crear_pestañas_principales(self, parent):
        """Crear pestañas con diseño mejorado"""
        self.notebook = ttk.Notebook(parent)
        self.notebook.pack(fill='both', expand=True, pady=(10, 0))
        
        self.crear_pestana_recomendaciones_mejorada()
        self.crear_pestana_busqueda_rapida()
        self.crear_pestana_agregar_pelicula()
        self.crear_pestana_catalogo()
    
    def crear_pestana_recomendaciones_mejorada(self):
        """Pestaña de recomendaciones con barra de rango mejorada"""
        frame = ttk.Frame(self.notebook, style='Professional.TFrame', padding="15")
        self.notebook.add(frame, text="🎯 Recomendaciones")
        
        # Header
        header_frame = ttk.Frame(frame, style='Professional.TFrame')
        header_frame.pack(fill='x', pady=(0, 15))
        
        ttk.Label(header_frame, text="Recomendaciones Personalizadas", 
                 font=('Segoe UI', 14, 'bold'), 
                 background=self.colors['light'],
                 foreground=self.colors['text_primary']).pack(anchor='w')
        
        ttk.Label(header_frame, 
                 text="Encuentra películas que se adapten a tus preferencias",
                 font=('Segoe UI', 9),
                 background=self.colors['light'],
                 foreground=self.colors['text_secondary']).pack(anchor='w')
        
        # Panel de filtros
        filters_card = ttk.Frame(frame, style='Card.TFrame', padding="20")
        filters_card.pack(fill='x', pady=(0, 15))
        
        # Géneros
        ttk.Label(filters_card, text="Géneros de interés (Separados por espacio)", 
                 font=('Segoe UI', 11, 'bold'),
                 background=self.colors['card_bg']).pack(anchor='w', pady=(0, 8))
        
        self.generos_var = tk.StringVar()
        generos_entry = ttk.Entry(filters_card, textvariable=self.generos_var,
                                 font=('Segoe UI', 10), width=50)
        generos_entry.pack(fill='x', pady=(0, 15))
        generos_entry.insert(0, "Ej: Acción Drama Comedia Romance")
        generos_entry.config(foreground='gray')
        generos_entry.bind('<FocusIn>', lambda e: self.limpiar_placeholder(e, "Ej: Acción Drama Comedia Romance"))
        generos_entry.bind('<FocusOut>', lambda e: self.restaurar_placeholder(e, "Ej: Acción Drama Comedia Romance"))
        
        # Barra de rango de puntuación MEJORADA
        ttk.Label(filters_card, text="Rango de puntuación", 
                 font=('Segoe UI', 11, 'bold'),
                 background=self.colors['card_bg']).pack(anchor='w', pady=(10, 15))
        
        # Contenedor principal para la barra de rango
        range_container = ttk.Frame(filters_card, style='Card.TFrame')
        range_container.pack(fill='x', pady=(0, 10))
        
        # Frame para valores actuales
        values_frame = ttk.Frame(range_container, style='Card.TFrame')
        values_frame.pack(fill='x', pady=(0, 10))
        
        self.min_label = ttk.Label(values_frame, text="Mín: 7.0", 
                                  font=('Segoe UI', 10, 'bold'),
                                  background=self.colors['card_bg'],
                                  foreground=self.colors['primary'])
        self.min_label.pack(side='left')
        
        self.max_label = ttk.Label(values_frame, text="Máx: 10.0", 
                                  font=('Segoe UI', 10, 'bold'),
                                  background=self.colors['card_bg'],
                                  foreground=self.colors['primary'])
        self.max_label.pack(side='right')
        
        # Frame para la barra de rango
        slider_frame = ttk.Frame(range_container, style='Card.TFrame')
        slider_frame.pack(fill='x')
        
        # Configurar variables
        self.min_rating = tk.DoubleVar(value=7.0)
        self.max_rating = tk.DoubleVar(value=10.0)
        
        # Slider mínimo
        min_slider = ttk.Scale(slider_frame, from_=0, to=10, 
                              variable=self.min_rating, 
                              orient='horizontal', length=400)
        min_slider.pack(fill='x', pady=2)
        min_slider.bind('<Motion>', self.actualizar_etiquetas_rango)
        min_slider.bind('<ButtonRelease-1>', self.actualizar_etiquetas_rango)
        
        # Slider máximo
        max_slider = ttk.Scale(slider_frame, from_=0, to=10, 
                              variable=self.max_rating, 
                              orient='horizontal', length=400)
        max_slider.pack(fill='x', pady=2)
        max_slider.bind('<Motion>', self.actualizar_etiquetas_rango)
        max_slider.bind('<ButtonRelease-1>', self.actualizar_etiquetas_rango)
        
        # Etiqueta de escala
        scale_labels = ttk.Frame(slider_frame, style='Card.TFrame')
        scale_labels.pack(fill='x')
        ttk.Label(scale_labels, text="0", font=('Segoe UI', 8),
                 background=self.colors['card_bg']).pack(side='left')
        ttk.Label(scale_labels, text="10", font=('Segoe UI', 8),
                 background=self.colors['card_bg']).pack(side='right')
        
        # Botón de búsqueda
        ttk.Button(filters_card, text="🔍 Buscar Recomendaciones", 
                  command=self.buscar_recomendaciones,
                  style='Primary.TButton', padding=(15, 8)).pack(pady=15)
        
        # Resultados
        self.crear_panel_resultados(frame)
    
    def crear_panel_resultados(self, parent):
        """Crear panel de resultados profesional"""
        results_card = ttk.Frame(parent, style='Card.TFrame')
        results_card.pack(fill='both', expand=True, pady=(10, 0))
        
        # Header de resultados
        results_header = ttk.Frame(results_card, style='Card.TFrame', padding="15")
        results_header.pack(fill='x')
        
        self.results_count_var = tk.StringVar(value="Realice una búsqueda para ver resultados")
        ttk.Label(results_header, textvariable=self.results_count_var,
                 font=('Segoe UI', 11, 'bold'),
                 background=self.colors['card_bg']).pack(side='left')
        
        ttk.Button(results_header, text="🔄 Limpiar", 
                  command=self.limpiar_resultados).pack(side='right')
        
        # Área de resultados
        self.results_text = scrolledtext.ScrolledText(results_card, 
                                                     font=('Segoe UI', 9),
                                                     wrap=tk.WORD, 
                                                     padx=15, pady=15,
                                                     borderwidth=0)
        self.results_text.pack(fill='both', expand=True)
    
    def crear_pestana_busqueda_rapida(self):
        """Pestaña de búsqueda rápida por ID"""
        frame = ttk.Frame(self.notebook, style='Professional.TFrame', padding="15")
        self.notebook.add(frame, text="🔎 Búsqueda Rápida")
        
        ttk.Label(frame, text="Búsqueda Rápida por ID", 
                 font=('Segoe UI', 14, 'bold'),
                 background=self.colors['light']).pack(anchor='w', pady=(0, 15))
        
        # Panel de búsqueda
        search_card = ttk.Frame(frame, style='Card.TFrame', padding="20")
        search_card.pack(fill='x', pady=(0, 15))
        
        search_frame = ttk.Frame(search_card, style='Card.TFrame')
        search_frame.pack(fill='x')
        
        ttk.Label(search_frame, text="ID de la película:", 
                 background=self.colors['card_bg'],
                 font=('Segoe UI', 11)).pack(side='left')
        
        self.id_var = tk.StringVar()
        id_entry = ttk.Entry(search_frame, textvariable=self.id_var, 
                           font=('Segoe UI', 11), width=15)
        id_entry.pack(side='left', padx=10)
        
        ttk.Button(search_frame, text="🔍 Buscar", 
                  command=self.buscar_por_id, 
                  style='Primary.TButton').pack(side='left')
        
        # Resultados
        result_card = ttk.LabelFrame(frame, text="📋 Información de la Película", 
                                   style='Card.TFrame', padding="15")
        result_card.pack(fill='both', expand=True)
        
        self.id_result_text = scrolledtext.ScrolledText(result_card, height=20,
                                                       font=('Segoe UI', 9),
                                                       wrap=tk.WORD, padx=15, pady=15)
        self.id_result_text.pack(fill='both', expand=True)
    
    def crear_pestana_agregar_pelicula(self):
        """Pestaña para agregar nuevas películas"""
        frame = ttk.Frame(self.notebook, style='Professional.TFrame', padding="15")
        self.notebook.add(frame, text="➕ Agregar Película")
        
        ttk.Label(frame, text="Agregar Nueva Película", 
                 font=('Segoe UI', 14, 'bold'),
                 background=self.colors['light']).pack(anchor='w', pady=(0, 15))
        
        # Formulario
        form_card = ttk.Frame(frame, style='Card.TFrame', padding="20")
        form_card.pack(fill='both', expand=True)
        
        # Campos del formulario
        campos = [
            ("🎬 Título:", "titulo_var", True),
            ("👨‍💼 Director:", "director_var", False),
            ("🏷️ Géneros (separados por espacio):", "generos_var", False),
            ("⭐ Puntuación (0.0-10.0):", "puntuacion_var", False),
            ("📅 Año:", "ano_var", False),
            ("⏱️ Duración (minutos):", "duracion_var", False)
        ]
        
        self.form_vars = {}
        
        for i, (label, var_name, required) in enumerate(campos):
            row = ttk.Frame(form_card, style='Card.TFrame')
            row.pack(fill='x', pady=8)
            
            label_text = f"{label} {'*' if required else ''}"
            ttk.Label(row, text=label_text, 
                     background=self.colors['card_bg'],
                     font=('Segoe UI', 10, 'bold' if required else 'normal')).pack(anchor='w')
            
            self.form_vars[var_name] = tk.StringVar()
            entry = ttk.Entry(row, textvariable=self.form_vars[var_name], 
                             font=('Segoe UI', 11))
            entry.pack(fill='x', pady=(5, 0))
        
        # Botón de agregar
        ttk.Button(form_card, text="🎬 Agregar Película", 
                  command=self.agregar_pelicula,
                  style='Primary.TButton', padding=(15, 10)).pack(pady=20)
        
        # Mensaje de resultado
        self.add_result_var = tk.StringVar()
        ttk.Label(form_card, textvariable=self.add_result_var,
                 background=self.colors['card_bg'],
                 font=('Segoe UI', 10),
                 foreground=self.colors['success']).pack()
    
    def crear_pestana_catalogo(self):
        """Pestaña para ver todas las películas"""
        frame = ttk.Frame(self.notebook, style='Professional.TFrame', padding="15")
        self.notebook.add(frame, text="📋 Catálogo Completo")
        
        # Header con controles
        header_frame = ttk.Frame(frame, style='Professional.TFrame')
        header_frame.pack(fill='x', pady=(0, 15))
        
        ttk.Label(header_frame, text="Catálogo Completo de Películas", 
                 font=('Segoe UI', 14, 'bold'),
                 background=self.colors['light']).pack(side='left')
        
        ttk.Button(header_frame, text="🔄 Actualizar", 
                  command=self.actualizar_lista).pack(side='right')
        
        # Lista de películas
        list_card = ttk.Frame(frame, style='Card.TFrame')
        list_card.pack(fill='both', expand=True)
        
        self.lista_text = scrolledtext.ScrolledText(list_card, height=25, 
                                                  font=('Segoe UI', 9),
                                                  wrap=tk.WORD, padx=15, pady=15)
        self.lista_text.pack(fill='both', expand=True)
        
        # Actualizar lista inicial
        self.actualizar_lista()

    # ==================== MÉTODOS DE UTILIDAD ====================
    
    def limpiar_placeholder(self, event, placeholder):
        """Limpiar texto placeholder al hacer focus"""
        if event.widget.get() == placeholder:
            event.widget.delete(0, tk.END)
            event.widget.config(foreground='black')
    
    def restaurar_placeholder(self, event, placeholder):
        """Restaurar placeholder si está vacío"""
        if event.widget.get() == '':
            event.widget.insert(0, placeholder)
            event.widget.config(foreground='gray')
    
    def actualizar_etiquetas_rango(self, event=None):
        """Actualizar las etiquetas del rango de puntuación"""
        min_val = round(self.min_rating.get(), 1)
        max_val = round(self.max_rating.get(), 1)
        
        # Asegurar que mínimo <= máximo
        if min_val > max_val:
            self.min_rating.set(max_val)
            min_val = max_val
        
        self.min_label.config(text=f"Mín: {min_val}")
        self.max_label.config(text=f"Máx: {max_val}")
    
    def actualizar_estado_sistema(self):
        """Actualizar las métricas del sistema"""
        try:
            diccionario = self.sistema.getDiccionario()
            total_peliculas = diccionario.size()
            
            # Calcular géneros únicos
            generos_unicos = set()
            puntuacion_total = 0.0
            contador_peliculas = 0
            
            if total_peliculas > 0:
                todos_ids = diccionario.obtenerTodosLosIds()
                for id_peli in todos_ids:
                    pelicula = self.sistema.buscarPeli(id_peli)
                    if pelicula:
                        contador_peliculas += 1
                        puntuacion_total += pelicula.getPuntuacion()
                        for genero in pelicula.getGenero():
                            generos_unicos.add(genero)
            
            # Calcular promedios
            puntuacion_promedio = puntuacion_total / contador_peliculas if contador_peliculas > 0 else 0.0
            
            # Actualizar interfaz
            self.metric_vars['total'].set(str(total_peliculas))
            self.metric_vars['generos'].set(str(len(generos_unicos)))
            self.metric_vars['puntuacion_promedio'].set(f"{puntuacion_promedio:.1f}")
            
        except Exception as e:
            print(f"Error actualizando estado: {e}")

    # ==================== MÉTODOS DE FUNCIONALIDAD ====================
    
    def buscar_recomendaciones(self):
        """Buscar recomendaciones con los filtros aplicados"""
        try:
            # Obtener géneros
            generos_texto = self.generos_var.get().strip()
            generos_lista = []
            
            if generos_texto and generos_texto != "Ej: Acción Drama Comedia Romance":
                generos_lista = generos_texto.split()
            
            # Obtener puntuaciones del rango
            min_punt = round(self.min_rating.get(), 1)
            max_punt = round(self.max_rating.get(), 1)
            
            # Validar rango
            if min_punt > max_punt:
                messagebox.showerror("Error", "El valor mínimo no puede ser mayor que el máximo")
                return
            
            # Realizar búsqueda
            if generos_lista:
                set_generos = set()
                for genero in generos_lista:
                    resultados_genero = self.sistema.buscarPorGenero(genero)
                    set_generos.update(resultados_genero)
            else:
                diccionario = self.sistema.getDiccionario()
                set_generos = set(diccionario.obtenerTodosLosIds())
            
            set_puntuacion = self.sistema.buscarPorRango(min_punt, max_punt)
            resultado_final = self.sistema.interseccion(set_generos, set_puntuacion)
            
            # Mostrar resultados
            self.mostrar_resultados_recomendaciones(resultado_final, len(set_generos), len(set_puntuacion))
            
        except Exception as e:
            messagebox.showerror("Error", f"Error en la búsqueda: {e}")
    
    def mostrar_resultados_recomendaciones(self, resultados, total_genero, total_puntuacion):
        """Mostrar resultados formateados"""
        self.results_text.delete(1.0, tk.END)
        
        if not resultados:
            self.results_text.insert(tk.END, "❌ No se encontraron películas que coincidan con los criterios de búsqueda.\n\n")
            self.results_text.insert(tk.END, "Sugerencias:\n")
            self.results_text.insert(tk.END, "• Amplíe el rango de puntuación\n")
            self.results_text.insert(tk.END, "• Reduzca la cantidad de géneros\n")
            self.results_text.insert(tk.END, "• Verifique la ortografía de los géneros\n")
            self.results_count_var.set("0 resultados encontrados")
            return
        
        self.results_count_var.set(f"{len(resultados)} películas encontradas")
        
        # Encabezado de resultados
        header = f"🎬 RECOMENDACIONES ENCONTRADAS ({len(resultados)})\n"
        header += "=" * 60 + "\n\n"
        self.results_text.insert(tk.END, header)
        
        # Lista de películas
        for i, id_peli in enumerate(sorted(resultados), 1):
            pelicula = self.sistema.buscarPeli(id_peli)
            if pelicula:
                self.results_text.insert(tk.END, f"{i}. {pelicula.getTitulo()} ({pelicula.getAno()})\n")
                self.results_text.insert(tk.END, f"   ⭐ {pelicula.getPuntuacion()}/10 | 🏷️ {', '.join(pelicula.getGenero())}\n")
                self.results_text.insert(tk.END, f"   👨‍💼 {pelicula.getDirector()} | ⏱️ {pelicula.getDuracion()} min | 📍 ID: {pelicula.getId()}\n")
                self.results_text.insert(tk.END, "\n")
    
    def buscar_por_id(self):
        """Buscar una película por su ID"""
        try:
            id_texto = self.id_var.get().strip()
            if not id_texto:
                messagebox.showwarning("Advertencia", "Por favor ingrese un ID")
                return
            
            id_peli = int(id_texto)
            pelicula = self.sistema.buscarPeli(id_peli)
            
            self.id_result_text.delete(1.0, tk.END)
            
            if pelicula:
                info = self.formatear_info_pelicula_detallada(pelicula)
                self.id_result_text.insert(tk.END, info)
            else:
                self.id_result_text.insert(tk.END, f"❌ No se encontró ninguna película con ID {id_peli}")
                
        except ValueError:
            messagebox.showerror("Error", "El ID debe ser un número entero válido")
        except Exception as e:
            messagebox.showerror("Error", f"Error en la búsqueda: {e}")
    
    def agregar_pelicula(self):
        """Agregar una nueva película al sistema"""
        try:
            # Validar campos obligatorios
            if not self.form_vars["titulo_var"].get().strip():
                messagebox.showwarning("Advertencia", "El título es obligatorio")
                return
            
            # Obtener y validar datos
            titulo = self.form_vars["titulo_var"].get().strip()
            director = self.form_vars["director_var"].get().strip() or "Desconocido"
            
            generos_texto = self.form_vars["generos_var"].get().strip()
            generos = generos_texto.split() if generos_texto else ["Sin género"]
            
            try:
                puntuacion = float(self.form_vars["puntuacion_var"].get() or 0)
                ano = int(self.form_vars["ano_var"].get() or 0)
                duracion = int(self.form_vars["duracion_var"].get() or 0)
            except ValueError:
                messagebox.showerror("Error", "Puntuación, año y duración deben ser números válidos")
                return
            
            # Validar rango de puntuación
            if not (0.0 <= puntuacion <= 10.0):
                messagebox.showerror("Error", "La puntuación debe estar entre 0.0 y 10.0")
                return
            
            # Agregar película
            nuevo_id = self.sistema.agregarPelicula(titulo, director, generos, puntuacion, ano, duracion)
            
            # Mostrar resultado
            self.add_result_var.set(f"✅ Película '{titulo}' agregada exitosamente con ID: {nuevo_id}")
            
            # Limpiar formulario
            for var in self.form_vars.values():
                var.set("")
            
            # Actualizar estado y lista
            self.actualizar_estado_sistema()
            self.actualizar_lista()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al agregar película: {e}")
    
    def actualizar_lista(self):
        """Actualizar la lista de todas las películas"""
        try:
            self.lista_text.delete(1.0, tk.END)
            
            diccionario = self.sistema.getDiccionario()
            todos_ids = diccionario.obtenerTodosLosIds()
            
            if not todos_ids:
                self.lista_text.insert(tk.END, "🎭 El sistema no contiene películas aún.\n")
                self.lista_text.insert(tk.END, "¡Ve a la pestaña 'Agregar Película' para comenzar!")
                return
            
            self.lista_text.insert(tk.END, f"📚 Catálogo completo: {len(todos_ids)} películas\n")
            self.lista_text.insert(tk.END, "=" * 70 + "\n\n")
            
            for id_peli in sorted(todos_ids):
                pelicula = self.sistema.buscarPeli(id_peli)
                if pelicula:
                    self.lista_text.insert(tk.END, self.formatear_info_pelicula(pelicula))
                    self.lista_text.insert(tk.END, "─" * 70 + "\n\n")
                    
        except Exception as e:
            self.lista_text.insert(tk.END, f"❌ Error cargando la lista: {e}\n")
    
    def limpiar_resultados(self):
        """Limpiar el área de resultados"""
        self.results_text.delete(1.0, tk.END)
        self.results_count_var.set("Resultados limpiados")
    
    def formatear_info_pelicula(self, pelicula):
        """Formatear información básica de película"""
        return (f"🎬 {pelicula.getTitulo()} ({pelicula.getAno()})\n"
                f"📍 ID: {pelicula.getId()} | 👨‍💼 Director: {pelicula.getDirector()}\n"
                f"⭐ Puntuación: {pelicula.getPuntuacion()}/10 | ⏱️ {pelicula.getDuracion()} min\n"
                f"🏷️ Géneros: {', '.join(pelicula.getGenero())}\n")
    
    def formatear_info_pelicula_detallada(self, pelicula):
        """Formatear información detallada de película"""
        return (f"🎬 {pelicula.getTitulo()}\n"
                f"{'=' * 50}\n"
                f"📍 ID: {pelicula.getId()}\n"
                f"👨‍💼 Director: {pelicula.getDirector()}\n"
                f"📅 Año: {pelicula.getAno()}\n"
                f"⭐ Puntuación: {pelicula.getPuntuacion()}/10\n"
                f"⏱️ Duración: {pelicula.getDuracion()} minutos\n"
                f"🏷️ Géneros: {', '.join(pelicula.getGenero())}\n"
                f"{'=' * 50}\n")

def main():
    try:
        from ctypes import windll
        windll.shcore.SetProcessDpiAwareness(1)
    except:
        pass
    
    root = tk.Tk()
    app = SistemaRecomendacionesProfesional(root)
    root.mainloop()

if __name__ == "__main__":
    main()