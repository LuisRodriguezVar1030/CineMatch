#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>
#include "../include/pelicula.h"
#include "../include/diccionario.h"
#include "../include/matriz.h"
#include "../include/avl.h"
#include "../include/sistema.h"

namespace py = pybind11;

PYBIND11_MODULE(recomendaciones, m) {
    m.doc() = "Sistema de recomendaciones de películas - Módulo Python";

    // ==================== CLASE PELICULA ====================
    py::class_<pelicula>(m, "Pelicula")
        .def(py::init<int, std::string, std::string, std::vector<std::string>, double, int, int>(),
             py::arg("id"), py::arg("titulo"), py::arg("director"), 
             py::arg("genero"), py::arg("puntuacion"), py::arg("ano"), py::arg("duracion"))
        .def("getId", &pelicula::getId)
        .def("getTitulo", &pelicula::getTitulo)
        .def("getDirector", &pelicula::getDirector)
        .def("getGenero", &pelicula::getGenero)
        .def("getPuntuacion", &pelicula::getPuntuacion)
        .def("getAno", &pelicula::getAno)
        .def("getDuracion", &pelicula::getDuracion)
        .def("setTitulo", &pelicula::setTitulo)
        .def("setDirector", &pelicula::setDirector)
        .def("setGenero", &pelicula::setGenero)
        .def("setPuntuacion", &pelicula::setPuntuacion)
        .def("setAno", &pelicula::setAno)
        .def("setDuracion", &pelicula::setDuracion);

    // ==================== CLASE DICCIONARIO ====================
    py::class_<diccionario>(m, "Diccionario")
        .def(py::init<>())
        .def("agregarPelicula", &diccionario::agregarPelicula)
        .def("eliminarPelicula", &diccionario::eliminarPelicula)
        .def("buscarPelicula", &diccionario::buscarPelicula, 
             py::return_value_policy::reference)
        .def("size", &diccionario::size)
        .def("obtenerTodosLosIds", &diccionario::obtenerTodosLosIds);

    // ==================== CLASE MATRIZ ====================
    py::class_<matriz>(m, "Matriz")
        .def(py::init<>())
        .def("agregarPelix", &matriz::agregarPelix)
        .def("buscarGenero", &matriz::buscarGenero);

    // ==================== CLASE AVL ====================
    py::class_<AVL>(m, "AVL")
        .def(py::init<>())
        .def("insertar", &AVL::insertar)
        .def("buscarRango", &AVL::buscarRango)
        .def("construirDesdeDiccionario", &AVL::construirDesdeDiccionario);

    // ==================== CLASE SISTEMA_RECOMENDADOR ====================
    py::class_<SistemaRecomendador>(m, "SistemaRecomendador")
        .def(py::init<>())
        .def("cargarPeliculasIniciales", &SistemaRecomendador::cargarPeliculasIniciales)
        .def("cargarDesdeArchivo", &SistemaRecomendador::cargarDesdeArchivo)
        .def("agregarPelicula", &SistemaRecomendador::agregarPelicula)
        .def("buscarPeli", &SistemaRecomendador::buscarPeli, 
             py::return_value_policy::reference)
        .def("buscarPorRango", &SistemaRecomendador::buscarPorRango)
        // FIX: Lambda para convertir string a vector<string>
        .def("buscarPorGenero", [](SistemaRecomendador& self, const std::string& genero) {
            return self.buscarPorGenero(std::vector<std::string>{genero});
        })
        .def("getDiccionario", &SistemaRecomendador::getDiccionario, 
             py::return_value_policy::reference)
        .def("interseccion", &SistemaRecomendador::interseccion);
}