#ifndef AVL_H
#define AVL_H

#include <vector>
#include <cstddef> 
#include <set>

class diccionario;   


struct NodoAVL {
    double puntuacion;          
    std::vector<int> ids;       
    int altura;
    NodoAVL* izq;
    NodoAVL* der;

    NodoAVL(double p, int id)
        : puntuacion(p), ids({id}), altura(1), izq(nullptr), der(nullptr) {}
};

class AVL {

private:
    NodoAVL* raiz;

    
    int altura(NodoAVL* nodo) const;
    int factorBalance(NodoAVL* nodo) const;

    NodoAVL* rotacionDerecha(NodoAVL* y);
    NodoAVL* rotacionIzquierda(NodoAVL* x);

    NodoAVL* insertarRec(NodoAVL* nodo, int id, double puntuacion);

    void buscarRangoRec(NodoAVL* nodo, double minP, double maxP, std::set<int>& resultado) const;

    void destruir(NodoAVL* nodo);

public:
    
    AVL() : raiz(nullptr) {}
    ~AVL();

    
    void insertar(int id, double puntuacion);

    std::set<int> buscarRango(double minP, double maxP) const;

    void construirDesdeDiccionario(const diccionario& d);
};

#endif
