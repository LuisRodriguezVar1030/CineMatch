#ifndef PELICULA_H
#define PELICULA_H
#include <string>
#include <vector>

class pelicula {
private:
    int id;
    std::string titulo;
    std::string director;
    std::vector<std::string> genero;
    double puntuacion;
    int ano;
    int duracion;

public:
    //Constructor
    pelicula(int id,
             const std::string& titulo,
             const std::string& director,
             const std::vector<std::string>& genero,
             double puntuacion,
             int ano,
             int duracion);

    //Métodos
    int getId() const;
    std::string getTitulo() const;
    std::string getDirector() const;
    const std::vector<std::string>& getGenero() const;
    double getPuntuacion() const;
    int getAno() const;
    int getDuracion() const;

    void setTitulo(const std::string& t);
    void setDirector(const std::string& di);
    void setGenero(const std::vector<std::string>& g);
    void setPuntuacion(double p);
    void setAno(int a);
    void setDuracion(int du);
};
#endif
