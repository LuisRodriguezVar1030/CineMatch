#ifndef MATRIZ_H
#define MATRIZ_H
#include <unordered_map> //Implementación de diccionarios en c++
#include <string>
#include <vector>
#include <set>
#include "pelicula.h"
#include "diccionario.h"

class matriz{
private:
    std::unordered_map<std::string, std::set<int>> matrix;
    bool existeGenero(std::string genero) const;
public:
    //Constructor   
    matriz()=default;

    //Metodos
    bool agregarPelix(const pelicula& p);
    std::set<int> buscarGenero(std::string)const;

};
#endif