#ifndef SISTEMA_H
#define SISTEMA_H

#include <string>
#include <vector>
#include <set>
#include <algorithm>
#include <iterator>
#include "diccionario.h"
#include "AVL.h"
#include "pelicula.h"
#include "matriz.h"

class SistemaRecomendador {

private:
    diccionario dic;    // géneros → IDs
    AVL arbol;          // puntuación → IDs
    matriz matrix;
    int ultimoID = 0;   // ID más alto usado

    int generarID();    // asigna ID automático

public:
    SistemaRecomendador() = default;

    // ---- CARGA INICIAL ----
    void cargarPeliculasIniciales(const std::vector<pelicula>& lista);
    bool cargarDesdeArchivo(const std::string& ruta);

    // ---- AGREGAR PELÍCULA ----
    int agregarPelicula(const std::string& titulo,
                        const std::string& director,
                        const std::vector<std::string>& generos,
                        double puntuacion,
                        int anio,
                        int duracion);

    // ---- CONSULTAS ----
    const pelicula* buscarPeli(int id) const;
    std::set<int> buscarPorRango(double minP, double maxP) const;
    std::set<int> buscarPorGenero(std::vector<std::string> filtro);
    // Acceso interno al diccionario (si lo necesitas)
    const diccionario& getDiccionario() const { return dic; }
    std::set<int> interseccion(const std::set<int>& a, const std::set<int>& b);

};

#endif