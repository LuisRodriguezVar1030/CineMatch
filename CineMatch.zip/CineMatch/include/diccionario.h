#ifndef DICCIONARIO_H
#define DICCIONARIO_H
#include "pelicula.h"
#include <unordered_map> //Implementación de diccionarios en c++

class diccionario{
private:
    std::unordered_map<int,pelicula> tabla;
    bool existePelicula(int id) const;
public:
    //Constructor   
    diccionario()=default;

    //Métodos
    bool agregarPelicula(const pelicula& p);
    bool eliminarPelicula(int id);
    const pelicula* buscarPelicula(int id) const;
    //void mostrarTodas() const;
    int size() const;
    std::vector<int> obtenerTodosLosIds() const;    

};

#endif