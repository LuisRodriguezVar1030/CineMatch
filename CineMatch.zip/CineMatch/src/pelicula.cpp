#include "pelicula.h"

pelicula::pelicula(int id,
             const std::string& titulo,
             const std::string& director,
             const std::vector<std::string>& genero,
             double puntuacion,
             int ano,
             int duracion)
    :id(id),
     titulo(titulo),
     director(director),
     genero(genero),
     puntuacion(puntuacion),
     ano(ano),
     duracion(duracion)
{}

int pelicula::getId() const {return id;}
std::string pelicula::getTitulo() const {return titulo;}
std::string pelicula::getDirector() const {return director;}
const std::vector<std::string>& pelicula::getGenero() const {return genero;}
double pelicula::getPuntuacion() const {return puntuacion;}
int pelicula::getAno() const {return ano;}
int pelicula::getDuracion() const {return duracion;}

void pelicula::setTitulo(const std::string& t) {titulo=t;}
void pelicula::setDirector(const std::string& di) {director=di;}
void pelicula::setGenero(const std::vector<std::string>& g) {genero=g;}
void pelicula::setPuntuacion(double p) {
    if (p<0.0) p=0.0;
    if (p>10.0) p=10.0;
    puntuacion=p;}  
void pelicula::setAno(int a) {ano=a;}
void pelicula::setDuracion(int du) {duracion=du;}