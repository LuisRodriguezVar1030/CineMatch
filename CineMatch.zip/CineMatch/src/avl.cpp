#include "avl.h"
#include "diccionario.h"   
#include <algorithm>  

/*Metodos para mantener el arbol balanceado y ordenado*/
int AVL::altura(NodoAVL* nodo) const {
    if (nodo == nullptr) 
        return 0;
    return nodo->altura;
}
int AVL::factorBalance(NodoAVL* nodo) const {
    if (nodo == nullptr)
        return 0;
    return altura(nodo->izq) - altura(nodo->der);
}
NodoAVL* AVL::rotacionDerecha(NodoAVL* y) {
    NodoAVL* x = y->izq;
    NodoAVL* T2 = x->der;

    //Rotaciones
    x->der = y;
    y->izq = T2;

    //Actualizar alturas
    y->altura = 1 + std::max(altura(y->izq), altura(y->der));
    x->altura = 1 + std::max(altura(x->izq), altura(x->der));

    return x;   //nueva raíz del subarbol
}
NodoAVL* AVL::rotacionIzquierda(NodoAVL* x) {
    NodoAVL* y = x->der;
    NodoAVL* T2 = y->izq;

    // Rotación
    y->izq = x;
    x->der = T2;

    // Actualizar alturas
    x->altura = 1 + std::max(altura(x->izq), altura(x->der));
    y->altura = 1 + std::max(altura(y->izq), altura(y->der));

    return y;  // nueva raíz del subárbol
}


AVL::~AVL() {
    destruir(raiz);
}

/*Destructor*/
void AVL::destruir(NodoAVL* nodo) {
    if (nodo == nullptr) return;
    destruir(nodo->izq);
    destruir(nodo->der);
    delete nodo;
}

/*Metodo para insertar pelicula a un arreglo o creando un nuevo nodo*/
void AVL::insertar(int id, double puntuacion) {
    raiz = insertarRec(raiz, id, puntuacion);
}


NodoAVL* AVL::insertarRec(NodoAVL* nodo, int id, double puntuacion) {
    //caso base: crear nodo nuevo si no existe
    if (nodo == nullptr) {
        return new NodoAVL(puntuacion, id);
    }

    //recorrer izquierdo o derecho según la puntuación 
    if (puntuacion < nodo->puntuacion) {
        nodo->izq = insertarRec(nodo->izq, id, puntuacion);
    }
    else if (puntuacion > nodo->puntuacion) {
        nodo->der = insertarRec(nodo->der, id, puntuacion);
    }
    else {
        // misma puntuación: añadir id al vector y devolver el nodo
        nodo->ids.push_back(id);
        return nodo; 
    }

    //actualizar altura del nodo ancestro
    nodo->altura = 1 + std::max(altura(nodo->izq), altura(nodo->der));

    //calcular factor de balance
    int balance = factorBalance(nodo);

    //aplicar rotaciones en los 4 casos del AVL
    //Left Left
    if (balance > 1 && puntuacion < nodo->izq->puntuacion) {
        return rotacionDerecha(nodo);
    }

    //Right Right
    if (balance < -1 && puntuacion > nodo->der->puntuacion) {
        return rotacionIzquierda(nodo);
    }

    //Left Right
    if (balance > 1 && puntuacion > nodo->izq->puntuacion) {
        nodo->izq = rotacionIzquierda(nodo->izq);
        return rotacionDerecha(nodo);
    }

    //Right Left
    if (balance < -1 && puntuacion < nodo->der->puntuacion) {
        nodo->der = rotacionDerecha(nodo->der);
        return rotacionIzquierda(nodo);
    }

    return nodo;
}

/*Metodo para construir desde diccionario: limpia y rellena el árbol*/
void AVL::construirDesdeDiccionario(const diccionario& d) {
    
    destruir(raiz);
    raiz = nullptr;

    std::vector<int> ids = d.obtenerTodosLosIds();

    for (int id : ids) {
        const pelicula* p = d.buscarPelicula(id);
        if (p) {
            insertar(id, p->getPuntuacion());
        }
    }
}

/*Metodo que devuelve un arreglo con la peliculas que estan puntuadas cierto intervalo*/
std::set<int> AVL::buscarRango(double minP, double maxP) const {
    std::set<int> resultado;
    buscarRangoRec(raiz, minP, maxP, resultado);
    return resultado;
}
void AVL::buscarRangoRec(NodoAVL* nodo,
                         double minP,
                         double maxP,
                         std::set<int>& resultado) const
{
    if (nodo == nullptr) 
        return;

    //Si el rango incluye puntuaciones menores → recorrer izquierda
    if (minP < nodo->puntuacion) {
        buscarRangoRec(nodo->izq, minP, maxP, resultado);
    }

    //Si la puntuación del nodo está en el rango, agregar todos los ids asociados a este nodo
    if (nodo->puntuacion >= minP && nodo->puntuacion <= maxP) {
        for (int id : nodo->ids) {
            resultado.insert(id);
        }
    }

    //Si el rango incluye puntuaciones mayores → recorrer derecha
    if (maxP > nodo->puntuacion) {
        buscarRangoRec(nodo->der, minP, maxP, resultado);
    }
}
