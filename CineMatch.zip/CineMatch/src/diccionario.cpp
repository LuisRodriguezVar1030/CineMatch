#include "diccionario.h"
#include <cstddef>

bool diccionario::existePelicula(int id) const{
    return tabla.find(id) != tabla.end();
};
/*Metodo que revisa el id de la pelicula que se desea agregar, 
si no existe en el diccionario lo agrega, de lo contrario no hace nada*/
bool diccionario::agregarPelicula(const pelicula& p){
    int id=p.getId();
    if (existePelicula(id)){
        return false;
    }
    tabla.insert({id, p});
    return true;
};
/*Metodo para eliminar peliculas por su id, 
si no existe el id retorna false*/

bool diccionario::eliminarPelicula(int id){
    if (!existePelicula(id))
        return false;
    tabla.erase(id);
    return true;
};

/*Metodo para buscar una pelicula en el diccionario, 
devuelve un apuntador a esta si la encuentra, de lo contrario devuelve el apuntador vacio*/
const pelicula* diccionario::buscarPelicula(int id) const{
    if (!existePelicula(id))
        return nullptr;
    return &(tabla.at(id));
};

/*Metodo para obtener el tamaño del diccionario*/
int diccionario::size() const{
    return tabla.size();
};

/*Metodo necesario para hacer la construccion del arbol*/
std::vector<int> diccionario::obtenerTodosLosIds() const {
    std::vector<int> ids;
    ids.reserve(tabla.size());

    for (const auto& par : tabla) {
        ids.push_back(par.first);
    }
    return ids;
}


