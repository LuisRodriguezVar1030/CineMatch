#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <sstream> // Para leer los géneros
#include <limits>  // Para limpiar el buffer de cin
#include "sistema.h"
#include "pelicula.h"

// --- Prototipos de funciones auxiliares ---
void imprimirMenu();
void imprimirPelicula(const pelicula* p);
void mostrarResultados(const std::set<int>& ids, const SistemaRecomendador& sistema);
void buscarPeliculas(SistemaRecomendador& sistema);
void buscarPorID(SistemaRecomendador& sistema);
void agregarPelicula(SistemaRecomendador& sistema);

// --- Función Principal ---
int main() {
    SistemaRecomendador sistema;

    // 1. Cargar las películas desde el archivo
    std::string archivo = "peliculas.csv";
    if (!sistema.cargarDesdeArchivo(archivo)) {
        std::cerr << "Error: No se pudo abrir el archivo " << archivo << std::endl;
        std::cerr << "Asegurese de crear 'peliculas.csv' en la misma carpeta." << std::endl;
        // Continuar sin datos o salir
        // return 1; 
    } else {
        std::cout << "¡Sistema de recomendación de películas cargado!" << std::endl;
        std::cout << "Se cargaron datos desde " << archivo << std::endl;
    }

    // 2. Bucle del menú principal
    int opcion = 0;
    while (opcion != 4) {
        imprimirMenu();
        std::cin >> opcion;

        // Limpiar el buffer de entrada en caso de error
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            opcion = 0; // Resetea la opción
        }
        
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Limpiar el newline

        switch (opcion) {
            case 1:
                buscarPeliculas(sistema);
                break;
            case 2:
                buscarPorID(sistema);
                break;
            case 3:
                agregarPelicula(sistema);
                break;
            case 4:
                std::cout << "Saliendo del sistema. ¡Adios!" << std::endl;
                break;
            default:
                std::cout << "Opcion no valida. Intente de nuevo." << std::endl;
                break;
        }
        std::cout << std::endl;
    }

    return 0;
}

// --- Implementación de funciones auxiliares ---

void imprimirMenu() {
    std::cout << "--- Menu Principal ---" << std::endl;
    std::cout << "1. Recomendar peliculas (por genero y puntuacion)" << std::endl;
    std::cout << "2. Buscar pelicula por ID" << std::endl;
    std::cout << "3. Agregar nueva pelicula" << std::endl;
    std::cout << "4. Salir" << std::endl;
    std::cout << "Seleccione una opcion: ";
}

// Imprime los detalles de una película
void imprimirPelicula(const pelicula* p) {
    if (p == nullptr) {
        std::cout << "  [Pelicula no encontrada]" << std::endl;
        return;
    }

    std::cout << "  ID: " << p->getId() << std::endl;
    std::cout << "  Titulo: " << p->getTitulo() << " (" << p->getAno() << ")" << std::endl;
    std::cout << "  Director: " << p->getDirector() << std::endl;
    std::cout << "  Puntuacion: " << p->getPuntuacion() << "/10" << std::endl;
    std::cout << "  Generos: ";
    const auto& generos = p->getGenero();
    for (size_t i = 0; i < generos.size(); ++i) {
        std::cout << generos[i] << (i == generos.size() - 1 ? "" : ", ");
    }
    std::cout << std::endl;
}

// Muestra la lista de resultados
void mostrarResultados(const std::set<int>& ids, const SistemaRecomendador& sistema) {
    if (ids.empty()) {
        std::cout << "No se encontraron peliculas que coincidan con su busqueda." << std::endl;
        return;
    }

    std::cout << "Resultados encontrados (" << ids.size() << "):" << std::endl;
    std::cout << "--------------------------" << std::endl;
    for (int id : ids) {
        imprimirPelicula(sistema.buscarPeli(id));
        std::cout << "--------------------------" << std::endl;
    }
}

// --- Lógica de las opciones del menú ---

// OPCIÓN 1: La prueba clave de intersección
void buscarPeliculas(SistemaRecomendador& sistema) {
    std::vector<std::string> generosFiltro;
    std::string lineaGeneros, genero;
    
    std::cout << "--- Buscar Recomendaciones ---" << std::endl;
    std::cout << "Escriba los generos que busca, separados por espacio (ej: Accion Sci-Fi Drama):" << std::endl;
    std::cout << "(Deje en blanco si no quiere filtrar por genero)" << std::endl;
    std::cout << "> ";
    
    getline(std::cin, lineaGeneros);
    std::stringstream ss(lineaGeneros);
    while (ss >> genero) {
        generosFiltro.push_back(genero);
    }

    double minP = 0.0, maxP = 10.0;
    std::cout << "Ingrese puntuacion minima (0.0 a 10.0): ";
    std::cin >> minP;
    std::cout << "Ingrese puntuacion maxima (0.0 a 10.0): ";
    std::cin >> maxP;

    // 1. Buscar por Género (tu función de sistema)
    // Si la lista de géneros está vacía, esto inteligentemente devuelve TODAS las películas
    std::set<int> set_generos = sistema.buscarPorGenero(generosFiltro);

    // 2. Buscar por Puntuación (tu función de sistema)
    std::set<int> set_puntuacion = sistema.buscarPorRango(minP, maxP);

    // 3. ¡LA INTERSECCIÓN!
    std::cout << "\nCalculando interseccion..." << std::endl;
    std::cout << "Peliculas por genero: " << set_generos.size() << std::endl;
    std::cout << "Peliculas por puntuacion: " << set_puntuacion.size() << std::endl;
    
    std::set<int> resultadoFinal = sistema.interseccion(set_generos, set_puntuacion);

    // 4. Mostrar resultados
    mostrarResultados(resultadoFinal, sistema);
}

// OPCIÓN 2: Probar el diccionario (Tabla Hash)
void buscarPorID(SistemaRecomendador& sistema) {
    int id;
    std::cout << "--- Buscar por ID ---" << std::endl;
    std::cout << "Ingrese el ID de la pelicula: ";
    std::cin >> id;
    
    std::cout << "\nBuscando pelicula..." << std::endl;
    const pelicula* p = sistema.buscarPeli(id);
    imprimirPelicula(p);
}

// OPCIÓN 3: Probar la inserción en todas las estructuras
void agregarPelicula(SistemaRecomendador& sistema) {
     std::string titulo, director, lineaGeneros, genero;
     std::vector<std::string> generos;
     double puntuacion;
     int anio, duracion;

    std::cout << "--- Agregar Nueva Pelicula ---" << std::endl;
    std::cout << "Titulo: ";
    getline(std::cin, titulo);
    std::cout << "Director: ";
    getline(std::cin, director);
    std::cout << "Generos (separados por espacio, ej: Comedia Drama): ";
    getline(std::cin, lineaGeneros);
    std::stringstream ss(lineaGeneros);
    while (ss >> genero) {
        generos.push_back(genero);
    }
    std::cout << "Puntuacion (0.0-10.0): ";
    std::cin >> puntuacion;
    std::cout << "Ano: ";
    std::cin >> anio;
    std::cout << "Duracion (minutos): ";
    std::cin >> duracion;

    int nuevoID = sistema.agregarPelicula(titulo, director, generos, puntuacion, anio, duracion);
    std::cout << "\nPelicula agregada exitosamente con ID: " << nuevoID << std::endl;
}