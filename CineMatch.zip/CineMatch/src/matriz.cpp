#include "matriz.h"

bool matriz::existeGenero(std::string genero) const{
    return matrix.find(genero) != matrix.end();
};

/*Metodo que revisa el id de la pelicula que se desea agregar, 
si no existe en el diccionario agrega los generos asociados, de lo contrario no hace nada*/

bool matriz::agregarPelix(const pelicula& p) {
    // Obtener los géneros
    std::vector<std::string> generos = p.getGenero();

    // Recorrer los géneros (usando un for-each de C++)
    for (const std::string& genero : generos) {
        matrix[genero].insert(p.getId());
    }
    return true;
}

std::set<int> matriz::buscarGenero(std::string genero) const {
    
    auto it = matrix.find(genero);

    if (it == matrix.end()) {
        // No se encontró el género. Devolver un set vacío.
        return std::set<int>{}; 
    } else {
        // Se encontró. Devolver el set asociado (it->second es el set).
        return it->second;
    }
};
