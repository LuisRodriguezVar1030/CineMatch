#include "sistema.h"
#include <fstream>
#include <sstream>

/*Metodo para generar un id sin necesidad de que el usuario
 se preocupe por esto*/

int SistemaRecomendador::generarID() {
    return ++ultimoID;
}


/*Metodo que hace la carga de pelicula inicial al diccionario*/

void SistemaRecomendador::cargarPeliculasIniciales(const std::vector<pelicula>& lista) {
    for (const auto& p : lista) {
        dic.agregarPelicula(p);
        matrix.agregarPelix(p);
        if (p.getId() > ultimoID)
            ultimoID = p.getId();
    }

    //construir el avl desde el diccionario
    arbol.construirDesdeDiccionario(dic);
}


/*Metodo para traer los datos de las peliculas desde un archivo*/

bool SistemaRecomendador::cargarDesdeArchivo(const std::string& ruta) {
    std::ifstream file(ruta);
    if (!file.is_open())
        return false;

    std::string line;

    
    getline(file, line);

    std::vector<pelicula> lista;

    while (getline(file, line)) {
        std::stringstream ss(line);
        std::string item;

        int id, anio, duracion;
        double puntuacion;
        std::string titulo, director, generosStr;

        getline(ss, item, ','); id = stoi(item);
        getline(ss, titulo, ',');
        getline(ss, director, ',');
        getline(ss, generosStr, ',');
        getline(ss, item, ','); puntuacion = stod(item);
        getline(ss, item, ','); anio = stoi(item);
        getline(ss, item, ','); duracion = stoi(item);

        std::vector<std::string> generos;
        std::stringstream sg(generosStr);
        while (getline(sg, item, ';'))
            generos.push_back(item);

        lista.emplace_back(id, titulo, director, generos, puntuacion, anio, duracion);
    }

    file.close();

    cargarPeliculasIniciales(lista);
    return true;
}


/*Metodo para agregar una nueva pelicula tanto al diccionario como al arbol*/

int SistemaRecomendador::agregarPelicula(const std::string& titulo,
                                         const std::string& director,
                                         const std::vector<std::string>& generos,
                                         double puntuacion,
                                         int anio,
                                         int duracion)
{
    int id = generarID();

    pelicula p(id, titulo, director, generos, puntuacion, anio, duracion);

    dic.agregarPelicula(p);
    matrix.agregarPelix(p);
    arbol.insertar(id, puntuacion);

    return id; 
}


const pelicula* SistemaRecomendador::buscarPeli(int id) const {
    // Simplemente llama a la función del diccionario y devuelve lo que encuentre
    return dic.buscarPelicula(id);
}

/*Metodo para hacer la busqueda por rango en el avl*/

std::set<int> SistemaRecomendador::buscarPorRango(double minP, double maxP) const {
    return arbol.buscarRango(minP, maxP);
}

/*Metodo para realizar intersecciones de conjuntos*/

std::set<int> SistemaRecomendador::interseccion(const std::set<int>& a, const std::set<int>& b) {
    
    std::set<int> resultado;

    // Esta es la función estándar de C++ para intersección de sets ordenados
    std::set_intersection(
        a.begin(), a.end(),   // Rango del primer set
        b.begin(), b.end(),   // Rango del segundo set
        std::inserter(resultado, resultado.begin()) // Dónde guardar el resultado
    );

    return resultado;
}

/*Metodo para hacer la busqueda por genero en la matriz */

std::set<int> SistemaRecomendador::buscarPorGenero(std::vector<std::string> filtros){
    if(filtros.empty()){
        std::set<int> a=buscarPorRango(0.0,10.0);
        return a;
    };
    std::set<int> a=matrix.buscarGenero(filtros[0]);
    if(filtros.size()>1){
        for(int i=1; i<filtros.size(); i++){
            a=interseccion(a,matrix.buscarGenero(filtros[i]));
        }
    }return a;
};